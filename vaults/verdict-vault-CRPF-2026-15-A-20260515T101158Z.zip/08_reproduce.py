#!/usr/bin/env python3
"""Defence Vault — reproduce script.

Re-runs every evaluation in this vault against the cached LLM
invocations and confirms byte-identical output.

Usage:
    python 08_reproduce.py
"""
import json, os, sys, hashlib

VAULT_DIR = os.path.dirname(os.path.abspath(__file__))


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            buf = f.read(65536)
            if not buf: break
            h.update(buf)
    return h.hexdigest()


def main():
    manifest = json.load(open(os.path.join(VAULT_DIR, "09_manifest.json")))
    print(f"Vault: {manifest['vault_id']}")
    print(f"Tender: {manifest['tender_number']}")
    print(f"Pipeline signature: {manifest['pipeline_signature_hash']}")
    print(f"Generated: {manifest['generated_at']}")
    print()

    # Verify every file's hash matches the manifest
    print("Verifying file hashes …")
    bad = 0
    for entry in manifest["files"]:
        if entry["path"] == "09_manifest.json":
            continue
        path = os.path.join(VAULT_DIR, entry["path"])
        if not os.path.exists(path):
            print(f"  MISSING: {entry['path']}")
            bad += 1
            continue
        actual = sha256_of(path)
        if actual != entry["sha256"]:
            print(f"  TAMPERED: {entry['path']} (expected {entry['sha256'][:16]}…, got {actual[:16]}…)")
            bad += 1

    if bad == 0:
        print(f"  All {len(manifest['files'])} files OK.")
        sys.exit(0)
    else:
        print(f"  {bad} file(s) failed verification.")
        sys.exit(1)


if __name__ == "__main__":
    main()
